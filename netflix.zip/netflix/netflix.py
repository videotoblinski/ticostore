from sdl2 import *
import sdl2.ext
import time

def nfx_header(renderer, title, shell):
  renderer.copy(shell.textures["nfx_banner"], None, (0,0,shell.screensize[0],128))
  shell.drawtext(title, "title", 172, 40, 1)

def nfx_start(shell):
  resources = sdl2.ext.Resources(__file__, "res")
  shell.loadtex("nfx_listitem", "nfx_listitem.png", False, resources)
  shell.stall("Netflix", "Starting Netflix...", "bgC")
  shell.loadtex("nfx_bgA", "nfx_bg.png", False, resources)
  shell.loadtex("nfx_banner", "nfx_banner.png", False, resources)
  shell.show_menu(["login","signup"], "Welcome to Netflix", "nfx_bgA", 240, shell.textures["nfx_listitem"], nfx_header)
  for i in shell.textures:
    if i.startswith("nfx"):
      shell.textures[i].destroy()
      sdl2.SDL_FreeSurface(shell.surfaces[i])
  return 0

def identify():
  return {
    "appname": "Netflix",
    "vendor": "Netflix, Inc.",
    "entrypoint": "nfx_start",
    "version": 1.0,
    "description": "Stream your favorite movies and TV shows over an internet connection directly to your TiVo box!"
  }

